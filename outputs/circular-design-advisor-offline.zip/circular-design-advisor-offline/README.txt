Circular Design Advisor - offline pack

Double-click dashboard_offline.html for the interactive dashboard,
or lci_workbook.html to browse the LCI workbook. Keep the three files
in the same folder. No internet or Python needed.

Illustrative data. Source: https://github.com/malleshkomal/circular-design-advisor
